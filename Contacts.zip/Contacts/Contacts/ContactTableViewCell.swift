//
//  ContactTableViewCell.swift
//  Contacts
//
//  Created by Meenu Singh on 29/11/18.
//  Copyright © 2018 Meenu Singh. All rights reserved.
//

import UIKit
import Letters

class ContactTableViewCell: UITableViewCell {
    @IBOutlet weak var personName: UILabel!
    @IBOutlet weak var personImage: UIImageView!
    @IBOutlet weak var personNumber: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var personCountry: UILabel!
    
    
    
    
    @IBOutlet weak var vi: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        personImage.layer.borderWidth = 2
        personImage.layer.masksToBounds = false
        personImage.layer.borderColor = UIColor.white.cgColor
        personImage.layer.cornerRadius = personImage.frame.height/2
        personImage.clipsToBounds = true
        
        
        vi.layer.shadowColor = UIColor.black.cgColor
        vi.layer.shadowOffset = CGSize(width: 0, height: 1)
        vi.layer.shadowRadius = 1
        vi.layer.shadowOpacity = 0.5
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func configure(name: String) {
        personName?.text = name
        personImage.setImage(string: name, color: UIColor.colorHash(name: name), circular: true)
    }
}
