//
//  ContactListVC.swift
//  Contacts
//
//  Created by Meenu Singh on 29/11/18.
//  Copyright © 2018 Meenu Singh. All rights reserved.
//

import UIKit
import Toast_Swift
import FirebaseStorage
import FirebaseDatabase
class ContactListVC: UIViewController, UITableViewDataSource, UITableViewDelegate,UISearchBarDelegate{
    
    @IBOutlet weak var contactsTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var addButton: UIButton!
    
    @IBOutlet weak var emptyText: UILabel!
    
    private var contacts = [Contact]()
    var filtered:[Contact] = []
    var searchActive : Bool = false
    var toastOFView : Int = Int()
    var valueNumber : Int = Int()
    var picture: UIImage?
    let indicator = GMDCircularProgressView(frame: CGRect(origin: CGPoint.zero, size: CGSize(width:50, height:50)))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setLoader()
        setToast()
        self.indicator.isHidden = false
        self.indicator.animateProgressView()
        emptyText.isHidden = true
        if toastOFView == 1{
            self.view.makeToast("Successfully Added")
        }
        
        contactsTableView.bounces = false
        
        valueNumber =  self.getContactList()
        print("********valueNumber************",valueNumber)
        
        searchBar.setImage(UIImage(named: ""), for: .clear, state: UIControl.State.normal)
        
        //Dismiss the keyboard from background Click
        let dismissKeyboardGesture = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        dismissKeyboardGesture.cancelsTouchesInView = true
        contactsTableView.addGestureRecognizer(dismissKeyboardGesture)
        
       // searchBar.enablesReturnKeyAutomatically = true
        //enablesReturnKeyAutomatically = NO;
        
    }
    
    func getContactList() -> Int{
        
        
        let singleMessageRef = Database.database().reference().child("userProfile")
        singleMessageRef.keepSynced(true)
        singleMessageRef.observeSingleEvent(of: .value, with: { (snapshot) in
            if snapshot.exists() {
                singleMessageRef.observe(.childAdded, with: { (snap) in
                    if snap.exists() {
                        let receivedMessage = snap.value as! [String: Any]
                        print("**********receivedMessage********",receivedMessage)
                        let name = receivedMessage["name"] as? String ?? ""
                        let phone = receivedMessage["phone"] as? String ?? ""
                        let email = receivedMessage["email"] as? String ?? ""
                        let timestamp = receivedMessage["timestamp"] as! Int
                        let country = receivedMessage["country"] as? String ?? ""
                        let imageName = receivedMessage["imageName"] as? String ?? ""
                        
                        
                        let contact = Contact(name: name, phone: phone, email: email,country: country,fileName: imageName)
                        self.contacts.append(contact)
                        self.contactsTableView.reloadData()
                        
                        self.toStopIndicator()
                    } })  }
            else{
                self.contactsTableView.isHidden = true
                self.emptyText.isHidden = false
                self.toStopIndicator()
                
            } })
        return contacts.count
    }
    
    
    func toStopIndicator(){
        
        self.indicator.animationDidStop(finished: false)
        self.indicator.isHidden = true;
        
    }
    
    
    @objc func hideKeyboard() {
        view.endEditing(true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(searchActive){
            return filtered.count
        }
        else{
            return contacts.count
            
        }}
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        contactsTableView.isHidden = false
        emptyText.isHidden = true
        //For All Contact List
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ContactTableViewCell
        //*********Search****************************
        if(searchActive){
            let feedName = filtered[indexPath.row].name
            cell!.configure(name: feedName )
            cell!.personNumber.text = filtered[indexPath.row].phone
            cell!.personCountry.text = filtered[indexPath.row].country
            cell!.email.text = filtered[indexPath.row].email
            
            let fileName = filtered[indexPath.row].fileName
            if let image = self.filtered[indexPath.row].picture {
                cell?.personImage.image = image
            } else {
                self.filtered[indexPath.row].downloadImage(indexpathRow: indexPath.row,fileName:fileName, completion: { (state,textMessage, index) in
                    if state == true {
                        DispatchQueue.main.async {
                            self.contactsTableView.reloadData()
                        } }
                    else{
                        self.view.makeToast(textMessage)
                    } }) }
            //*********Contacts****************************
        }
        else {
            let feedName = contacts[indexPath.row].name
            cell!.configure(name: feedName )
            cell!.personNumber.text = contacts[indexPath.row].phone
            let fileName = contacts[indexPath.row].fileName
            cell!.personCountry.text = contacts[indexPath.row].country
            cell!.email.text = contacts[indexPath.row].email
            
            if let image = self.contacts[indexPath.row].picture {
                cell?.personImage.image = image
                
            } else {
                self.contacts[indexPath.row].downloadImage(indexpathRow: indexPath.row,fileName:fileName, completion: { (state,textMessage,index)  in
                    if state == true {
                        DispatchQueue.main.async {
                            self.contactsTableView.reloadData()
                        } }
                    else{
                        self.view.makeToast(textMessage) // now uses
                    } }) }  }
        self.indicator.animationDidStop(finished: false)
        self.indicator.isHidden = true;
        return cell!
        
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 100.0;//Choose your custom row height
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath as IndexPath) as! ContactTableViewCell
        
        
      }
    
    
    
    //Search bar Function******
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true
         print("searchBarTextDidBeginEditing")
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchActive = false
        print("searchBarTextDidEndEditing")
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false
        print("searchBarCancelButtonClicked")
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false
        print("searchBarSearchButtonClicked")
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
       print("searchBar")
        self.indicator.isHidden = false
        self.indicator.animateProgressView()
        filtered.removeAll()
        if(searchText.count == 0)
        {
            searchActive = false
        }
        else
        {
            searchActive = true
            for searchCountry in contacts{
                let tmp: NSString = searchCountry.name as NSString
                let range = tmp.range(of:searchText,options:NSString.CompareOptions.caseInsensitive)
                if range.location != NSNotFound{
                    filtered.append(searchCountry)
                } } }
        self.contactsTableView.reloadData()
        self.indicator.animationDidStop(finished: false)
        self.self.indicator.isHidden = true;
        
    }
    
    
    //Loader**Creation****
    func setLoader() {
        print("**** loader initalised ****")
        indicator.center = self.view.center
        self.view.addSubview(indicator)
        indicator.isHidden = true;
    }
    
    //Toast*****Creation*
    func setToast(){
        var style = ToastStyle()
        style.messageColor = .white
        ToastManager.shared.style = style
        ToastManager.shared.isTapToDismissEnabled = true
        ToastManager.shared.isQueueEnabled = true
    }
    
    func configure(name: String,cellImage:ContactTableViewCell) {
        cellImage.personImage.setImage(string: name, color: UIColor.colorHash(name: name), circular: true)
    }
    
}
