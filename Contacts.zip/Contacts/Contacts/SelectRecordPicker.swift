//
//  SelectRecordPicker.swift
//  Contacts
//
//  Created by Meenu Singh on 29/11/18.
//  Copyright © 2018 Meenu Singh. All rights reserved.
//

import Foundation
import Photos
import NohanaImagePicker
import MobileCoreServices

protocol addRecordDelegate {
func passingRecordImage(imageData:UIImage)
}

class SelectRecordPicker: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,NohanaImagePickerControllerDelegate{
    
    
    static func instantiate() -> SelectRecordPicker? {
        return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "\(SelectRecordPicker.self)") as? SelectRecordPicker
    }
    
  
    let imagePicker = UIImagePickerController()
    var addRecordDelegates: addRecordDelegate?
    var imageThumbNail:UIImage = UIImage()
    
    @IBOutlet weak var addPic: UILabel!
    @IBOutlet weak var takePic: UILabel!
    @IBOutlet weak var uploadPic: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        }
    
    @IBAction func takePhotoButtonClicked(_ sender: Any) {
        print("take photo button clicked")
       // addRecordDelegates?.dismissRecordsPicker()
        takePhoto()
    }
    
    @IBAction func uploadGalleryButtonClicked(_ sender: Any) {
        print("upload gallery button clicked")
       // addRecordDelegates?.dismissRecordsPicker()
        galleryOpen()
    }
    
  
    func takePhoto(){
        // your code goes here
        print("camera button clicked")
        AVCaptureDevice.requestAccess(for: AVMediaType.video) { response in
            if response {
                //access granted
                let deviceHasCamera = UIImagePickerController.isCameraDeviceAvailable(UIImagePickerController.CameraDevice.rear) || UIImagePickerController.isCameraDeviceAvailable(UIImagePickerController.CameraDevice.front)
                if deviceHasCamera {
                    let status = AVCaptureDevice.authorizationStatus(for: AVMediaType.video)
                    let userAgreedToUseIt = status == .authorized
                    if userAgreedToUseIt {
                        self.imagePicker.sourceType = .camera
                        self.imagePicker.allowsEditing = false
                        UserDefaults.standard.set("camera", forKey: "typeString")
                        self.present(self.imagePicker, animated: true, completion: nil)
                        
                        print("Inside camera*****11********")
                        
                    }
                    
                } else {
                    let alert = UIAlertController(title: "Camera access denied", message: "You need to go to settings app and grant acces to the camera device to use it.", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        print("Inside camera***22**********")
        
        let _:String =  UserDefaults.standard.object(forKey:"typeString") as! String
        let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
            
        print("captured image is-->>",pickedImage)
        picker.dismiss(animated: true, completion: nil)
        imageThumbNail = pickedImage
        self.dismiss(animated: true, completion: nil)
        self.addRecordDelegates?.passingRecordImage(imageData:imageThumbNail)
       

        
         
    }
    func GotoNextPage(newimage:UIImage){
        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: nil)
            
        }
          self.addRecordDelegates?.passingRecordImage(imageData:newimage)
    }
    
    func galleryOpen(){
        checkIfAuthorizedToAccessPhotos { isAuthorized in
            DispatchQueue.main.async(execute: {
                if isAuthorized {
                    self.showLargeThumbnailPicker()
                } else {
                    let alert = UIAlertController(title: "Error", message: "Denied access to photos.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            })
        }
    }
    
    @objc func showLargeThumbnailPicker() {
        let picker = NohanaImagePickerController()
        picker.delegate = self as? NohanaImagePickerControllerDelegate
        picker.numberOfColumnsInPortrait = 2
        picker.numberOfColumnsInLandscape = 3
        picker.maximumNumberOfSelection = 1
        present(picker, animated: true, completion: nil)
    }
    func checkIfAuthorizedToAccessPhotos(_ handler: @escaping (_ isAuthorized: Bool) -> Void) {
        switch PHPhotoLibrary.authorizationStatus() {
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { status in
                DispatchQueue.main.async {
                    switch status {
                    case .authorized:
                        handler(true)
                    default:
                        handler(false)
                    }
                }
            }
        case .restricted:
            handler(false)
        case .denied:
            handler(false)
        case .authorized:
            handler(true)
        }
    }
    
    func nohanaImagePickerDidCancel(_ picker: NohanaImagePickerController) {
        print("Cancelled")
        picker.dismiss(animated: true, completion: nil)
    }
    
    func nohanaImagePicker(_ picker: NohanaImagePickerController, didFinishPickingPhotoKitAssets pickedAssts: [PHAsset]) {
        for friendUids_child in pickedAssts {
            let manager = PHImageManager.default()
            let option = PHImageRequestOptions()
            var thumbnail = UIImage()
            option.isSynchronous = true
            manager.requestImage(for: friendUids_child, targetSize: CGSize(width: 200.0, height: 400.0), contentMode: .aspectFit, options: option, resultHandler: {(result, info)->Void in
                thumbnail = result!
                print("thumbnail from the gallery is-->>",thumbnail)
                self.imageThumbNail = thumbnail
            })
        }
        picker.dismiss(animated: true, completion: nil)
        GotoNextPage(newimage:imageThumbNail)
    }
    
   
}
