//
//  AddContactVC.swift
//  Contacts
//
//  Created by Meenu Singh on 29/11/18.
//  Copyright © 2018 Meenu Singh. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import Alamofire
import DropDown
import Firebase

import FirebaseStorage
import FirebaseDatabase
import EzPopup
import Toast_Swift
class AddContactVC: UIViewController,addRecordDelegate {
    
    let addRecordAlertVC = SelectRecordPicker.instantiate()
    
    let indicator = GMDCircularProgressView(frame: CGRect(origin: CGPoint.zero, size: CGSize(width:50, height:50)))
    
    
    let countryDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.countryDropDown
        ]
    }()
    
    @IBOutlet weak var countryPickerButton: UIButton!
    
    @IBOutlet weak var name: ACFloatingTextfield!
    @IBOutlet weak var nameError: UILabel!
    
    
    @IBOutlet weak var phoneNumber: ACFloatingTextfield!
    @IBOutlet weak var phoneError: UILabel!
    
    
    @IBOutlet weak var emaiAdd: ACFloatingTextfield!
    @IBOutlet weak var emailError: UILabel!
    
    
    @IBOutlet weak var country: ACFloatingTextfield!
    @IBOutlet weak var countryError: UILabel!
    
    @IBOutlet weak var add: UIButton!
    @IBOutlet weak var profilePic: UIImageView!
    
    fileprivate var returnHandler : IQKeyboardReturnKeyHandler!
    
    @IBOutlet weak var sc: UIScrollView!
    
    deinit {
        returnHandler = nil
    }
    
    var countryNameArray:[String] = [String]()
    var contacts = [Contact]()
    
    // private var contacts = [Contact]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setLoader()
        self.setToast()
        self.hideError()
        self.gettingCountryName()
        self.customizeDropDown(self)
        sc.bounces = false
        returnHandler = IQKeyboardReturnKeyHandler(controller: self)
        returnHandler.lastTextFieldReturnKeyType = .done
        
        profilePic.layer.borderWidth = 2
        profilePic.layer.masksToBounds = false
        profilePic.layer.borderColor = UIColor.white.cgColor
        profilePic.layer.cornerRadius = profilePic.frame.height/2
        profilePic.clipsToBounds = true
        
        
        // self.configViews()
        add.layer.cornerRadius = add.frame.height/2
        add.layer.masksToBounds = true
        
        
        //********Name
        name.placeholder = "Name"
        name.text = ""
        name.lineColor = UIColor.black
        name.placeHolderColor = UIColor.black
        name.selectedPlaceHolderColor =  UIColor.black
        name.lineColor =  UIColor.black
        
        //********phone number
        phoneNumber.placeholder = "Phone Number"
        phoneNumber.text = ""
        phoneNumber.lineColor = UIColor.black
        phoneNumber.placeHolderColor = UIColor.black
        phoneNumber.selectedPlaceHolderColor =  UIColor.black
        phoneNumber.lineColor =  UIColor.black
        
        //********Email
        emaiAdd.placeholder = "Email Address"
        emaiAdd.text = ""
        emaiAdd.lineColor = UIColor.black
        emaiAdd.placeHolderColor = UIColor.black
        emaiAdd.selectedPlaceHolderColor =  UIColor.black
        emaiAdd.lineColor =  UIColor.black
        
        //********Country
        country.placeholder = "Country"
        country.text = ""
        country.lineColor = UIColor.black
        country.placeHolderColor = UIColor.black
        country.selectedPlaceHolderColor =  UIColor.black
        country.lineColor =  UIColor.black
        
        
        if profilePic.image?.imageAsset == nil{
            configure(name:"Name" )
            
        }
         }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
         sc.contentSize = CGSize(width: view.bounds.width, height: 560)
    }
    
    
    //Textfield Start Editing
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("TextField did begin editing method called")
        
        if textField == name{
            configure(name:name.text!)
            name.lineColor =  UIColor.black
            nameError.isHidden = true
            
        }
        else if textField == phoneNumber{
            phoneNumber.lineColor =  UIColor.black
            phoneError.isHidden = true
        }
        else if textField == emaiAdd{
            emaiAdd.lineColor =  UIColor.black
            emailError.isHidden = true
        }
        else
        {
            country.lineColor =  UIColor.black
            countryError.isHidden = true
        }
        
    }
    
    func hideError(){
        
        nameError.isHidden = true
        phoneError.isHidden = true
        emailError.isHidden = true
        countryError.isHidden = true
        
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        if textField == name{
            if (name.text?.elementsEqual(""))!{
            configure(name:"Name")
            }
            else{
            configure(name:name.text!)
            }
        }
        return true
        
    }
    
    @IBAction func addContact(_ sender: Any)
    {
        self.view.endEditing(true)
        
        forstartingAnimation()
        
        if (name.text?.isEmpty == true && phoneNumber.text?.isEmpty == true && emaiAdd.text?.isEmpty == true && country.text?.isEmpty == true)
        {
            
            name.lineColor =  UIColor.red
            phoneNumber.lineColor =  UIColor.red
            emaiAdd.lineColor =  UIColor.red
            country.lineColor =  UIColor.red
            
            nameError.isHidden = false
            phoneError.isHidden = false
            emailError.isHidden = false
            countryError.isHidden = false
            
            nameError.text = "Name is Empty"
            phoneError.text = "Phone is Empty"
            emailError.text = "Email is Empty"
            countryError.text = "Country is Empty"
            
            forStoppingAnimation()
        }
            
            //code for not valid phoneNumber
        else  if (phoneNumber.text?.count)! <= 9
        {
            
            phoneError.isHidden = false
            phoneError.text = "Phone number should have 10 Digit"
            forStoppingAnimation()
        }
        else  if (phoneNumber.text!.isValidContact() == false)
        {
            
            phoneError.isHidden = false
            phoneError.text = "Phone number is not valid"
            forStoppingAnimation()
        }
            //
            
            //code for not valid email address
        else if emaiAdd.text!.isValidEmail() == false
        {
            
            emailError.isHidden = false
            emailError.text = "Email Address is not Valid"
            forStoppingAnimation()
        }
            
        else if name.text?.isEmpty == true
        {
            
            name.lineColor =  UIColor.red
            nameError.isHidden = false
            phoneError.isHidden = true
            emailError.isHidden = true
            countryError.isHidden = true
            nameError.text = "Name is Empty"
            forStoppingAnimation()
        }
        else if phoneNumber.text?.isEmpty == true
        {
            
            phoneNumber.lineColor =  UIColor.red
            nameError.isHidden = true
            phoneError.isHidden = false
            emailError.isHidden = true
            countryError.isHidden = true
            phoneError.text = "Phone is Empty"
            forStoppingAnimation()
        }
        else if emaiAdd.text?.isEmpty == true
        {
            
            emaiAdd.lineColor =  UIColor.red
            nameError.isHidden = true
            phoneError.isHidden = true
            emailError.isHidden = false
            countryError.isHidden = true
            emailError.text = "Email is Empty"
            forStoppingAnimation()
        }
            
        else if country.text?.isEmpty == true
        {
            
            country.lineColor =  UIColor.red
            nameError.isHidden = true
            phoneError.isHidden = true
            emailError.isHidden = true
            countryError.isHidden = false
            countryError.text = "Country is Empty"
            forStoppingAnimation()
        }
        else{
            sendProfileDataToFireBase()
        }
     }
    
    
    func forStoppingAnimation()
    {
        self.indicator.animationDidStop(finished: false)
        self.indicator.isHidden = true;
    }
    
    func forstartingAnimation()
    {
        self.indicator.isHidden = false
        self.indicator.animateProgressView()
    }
    
    
    func forSlowDownTheViewChange(){
        // DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
        // Code to push/present new view controller
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let contactVC = storyboard.instantiateViewController(withIdentifier: "ContactListVC") as! ContactListVC
        contactVC.toastOFView = 1
        self.present(contactVC, animated: true, completion: nil)
        self.forStoppingAnimation()
        // }
        
    }
    
    //******Getting the Country List from API
    func gettingCountryName(){
        let urlString = URL(string:"https://restcountries.eu/rest/v1/all")!
        Alamofire.request(urlString, method: .get, parameters:nil, encoding: URLEncoding.default, headers: nil).validate(statusCode: 200..<300).responseJSON {
            
            response in switch response.result
            {
            case .success(let JSon):
                let successResponse = JSon as! NSArray
                for i in 0 ..< successResponse.count{
                    let updatedAtValue:String = (((successResponse[i]) as AnyObject).value(forKey: "name") as! String)
                    self.countryNameArray.append(updatedAtValue)
                }
                
                self.setupDropDown(nameArray:self.countryNameArray)
            case .failure(let error):
                print(error)
                debugPrint(response)
            }
        }
    }
    
    @IBAction func countryClick(_ sender: Any) {
        self.view.endEditing(true)
        country.lineColor =  UIColor.black
        countryError.isHidden = true
        countryDropDown.show()
    }
    
    
    
    //DropDown Creation
    func customizeDropDown(_ sender: AnyObject) {
        let appearance = DropDown.appearance()
        appearance.cellHeight = 60
        appearance.backgroundColor = UIColor(white: 1, alpha: 1)
        appearance.selectionBackgroundColor = UIColor(red: 0.6494, green: 0.8155, blue: 1.0, alpha: 0.2)
        appearance.cornerRadius = 10
        appearance.shadowColor = UIColor(white: 0.6, alpha: 1)
        appearance.shadowOpacity = 0.9
        appearance.shadowRadius = 25
        appearance.animationduration = 0.25
        appearance.textColor = UIColor.black
        dropDowns.forEach {
            /*** FOR CUSTOM CELLS ***/
            $0.cellNib = UINib(nibName: "MyCell", bundle: nil)
            
            $0.customCellConfiguration = { (index: Index, item: String, cell: DropDownCell) -> Void in
                guard let cell = cell as? MyCell else { return }
                
                cell.suffixLabel.text = "Suffix \(index)"
            }
            /*** ---------------- ***/
        }
    }
    
    //DropDown - Setting the Country List
    func setupDropDown(nameArray:[String]) {
        countryDropDown.anchorView = countryPickerButton
        countryDropDown.bottomOffset = CGPoint(x: 0, y: countryPickerButton.bounds.height)
        countryDropDown.dataSource = countryNameArray
        countryDropDown.selectionAction = { [weak self] (index, item) in
            self?.country.text = item
            
        }
    }
    
    
    //Loader Creation
    func setLoader() {
        print("**** loader initalised ****")
        indicator.center = self.view.center
        self.view.addSubview(indicator)
        indicator.isHidden = true;
    }
    
    
    func sendProfileDataToFireBase()  {
        print("******inside firbase******")
        let name = self.name.text ?? ""
        let phone = self.phoneNumber.text ?? ""
        let email = self.emaiAdd.text ?? ""
        let country = self.country.text ?? ""
        let timestamp = Int(NSDate().timeIntervalSince1970 * 1000)
        let imageName =  sendingImageToFirebase()
        
        let profile_data = ["name": name, "phone": phone, "email": email,"timestamp": timestamp, "country": country,"imageName":imageName] as [String : Any]
        let databaseRef = Database.database().reference()
        databaseRef.child("user").observeSingleEvent(of: DataEventType.value, with: { (snapshot) in
            
            let ref = Database.database().reference().child("userProfile").childByAutoId()
            ref.keepSynced(true)
            ref.setValue(profile_data)
            self.forSlowDownTheViewChange()
            
        })
        { (error) in
            self.view.makeToast("Fail to Save")
            self.forStoppingAnimation()
        }
    }
    
    func sendingImageToFirebase() -> String {
        print("in send to firebase")
        let downloadGroup = DispatchGroup()
        let _ = DispatchQueue.global(qos: .userInitiated)
        let storage = Storage.storage()
        let storageReference = storage.reference()
        let lexokey = makePushID()
        let imageName = "\(lexokey).jpeg"
       
        let imagesReference = storageReference.child("ProfilePicture/").child(imageName)
        // Create a storage reference from our storage service
        DispatchQueue.main.async {
            if let imageData = self.profilePic.image?.jpegData(compressionQuality: 1.0) {
                _ = imagesReference.putData(imageData, metadata: nil, completion: { (metadata, error) in
                    imagesReference.downloadURL { (url, error) in
                        if let downloadURL = url{
                            let _: String = downloadURL.absoluteString
                            
                        }
                        else {
                            print("*****************error in downloading********************")
                        }
                    }
                })
            }
        }
        
        downloadGroup.notify(queue: DispatchQueue.main) {
            print("on completion of task")
        }
       return imageName
    }
    
    func passingRecordImage(imageData: UIImage) {
        self.profilePic.image = imageData
    }
    
    @IBAction func addPhoto(_ sender: Any) {
        
        let popupVC = PopupViewController(contentController: addRecordAlertVC!, position: .bottom(0), popupWidth: view.frame.width, popupHeight: 200)
        addRecordAlertVC?.addRecordDelegates = self
        popupVC.cornerRadius = 0
        present(popupVC, animated: true, completion: nil)
        
    }
    
    func setToast(){
        // create a new style
        var style = ToastStyle()
        style.messageColor = .white
        ToastManager.shared.style = style
        ToastManager.shared.isTapToDismissEnabled = true
        ToastManager.shared.isQueueEnabled = true
    }
    
    
    func configure(name: String) {
        profilePic.setImage(string: name, color: UIColor.colorHash(name: name), circular: true)
    }
    
    
    
}
extension AddContactVC: UITextFieldDelegate {}
//For adding the maxlength of the character in textfield
private var __maxLengths = [UITextField: Int]()
extension UITextField {
    @IBInspectable var maxLength: Int {
        get {
            guard let l = __maxLengths[self] else {
                return 150 // (global default-limit. or just, Int.max)
            }
            return l
        }
        set {
            __maxLengths[self] = newValue
            addTarget(self, action: #selector(fix), for: .editingChanged)
        }
    }
    @objc func fix(textField: UITextField) {
        let t = textField.text
        textField.text = t?.safelyLimitedTo(length: maxLength)
    }
}
extension String
{
    func safelyLimitedTo(length n: Int)->String {
        if (self.count <= n) {
            return self
        }
        return String( Array(self).prefix(upTo: n) )
    }
    
    func isValidEmail() -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: self)
    }
    
    func isValidContact() -> Bool {
        let phoneNumberRegex = "^[6-9]\\d{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        let isValidPhone = phoneTest.evaluate(with: self)
        return isValidPhone
    }
}
