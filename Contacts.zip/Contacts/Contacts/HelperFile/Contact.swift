//
//  Contact.swift
//  Contacts
//
//  Created by Meenu Singh on 29/11/18.
//  Copyright © 2018 Meenu Singh. All rights reserved.
//
import Foundation
import UIKit

import FirebaseStorage
import FirebaseDatabase
class Contact {
   
    var name: String
    var phone: String
    var email: String
    var country: String
     var fileName: String
     var picture: UIImage?

    init(name: String, phone: String, email: String,country: String,fileName:String) {
       
        self.name = name
        self.phone = phone
        self.email = email
        self.country = country
       self.fileName = fileName
    }
    
    
    
    
    func downloadImage(indexpathRow: Int,fileName:String, completion: @escaping (Bool,String, Int) -> Swift.Void)  {
        
        //For local file
        let fileManager = FileManager.default
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let filePathToWrite = "\(paths)/\(fileName)"
        
        //For firebase
        let storage = Storage.storage()
        let storageReference = storage.reference()
        let imagesReference = storageReference.child("ProfilePicture/\(fileName)")
        let reference: StorageReference = storage.reference(forURL: "\(imagesReference)")
        if (fileManager.fileExists(atPath: filePathToWrite))
        {
            print("FILE AVAILABLE");
            let imageUrl: URL = URL(fileURLWithPath: filePathToWrite)
            DispatchQueue.global().async { [weak self] in
                if let data = try? Data(contentsOf: imageUrl) {
                    if let image = UIImage(data: data) {
                        DispatchQueue.main.async {
                            self?.picture = image
                            let _: NSData = (self?.picture)!.pngData()! as NSData
                            completion(true,"Downloading Image", indexpathRow)
                        }
                    }
                }
            }
        }
        else
        {
            print("FILE NOT AVAILABLE 11");
            reference.downloadURL { (imageURL, error) in
                DispatchQueue.global().async { [weak self] in
                    if imageURL != nil{
                     if let data = try? Data(contentsOf: imageURL!) {
                            if let image = UIImage(data: data) {
                                DispatchQueue.main.async {
                                    let imageData: NSData = image.pngData()! as NSData
                                    self?.picture  = image
                                    //self!.clinicImageValue = image
                                    fileManager.createFile(atPath: filePathToWrite, contents: imageData as Data, attributes: nil)
                                     completion(true,"Downloading Image", indexpathRow)
                                }}}}
                    else{
                      print("*******NO IMAGE FOUND**********")
                         completion(true,"No Image Found", indexpathRow)
                    }} } }
        
    }
    
    
    
    
    
}
