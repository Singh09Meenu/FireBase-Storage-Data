//
//  MyCell.swift
//  Contacts
//
//  Created by Meenu Singh on 29/11/18.
//  Copyright © 2018 Meenu Singh. All rights reserved.
//
import UIKit
import DropDown

class MyCell: DropDownCell {
    
    @IBOutlet weak var suffixLabel: UILabel!
    
}
